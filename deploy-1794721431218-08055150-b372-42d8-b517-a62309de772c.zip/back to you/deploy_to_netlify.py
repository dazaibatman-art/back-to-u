"""
Deploy Group No1 to Netlify via the Netlify API (ZIP deploy).
Uses the proxy token embedded in the MCP deploy URL.
"""

import os
import io
import sys
import json
import zipfile
import hashlib
import requests
from pathlib import Path

# ─── Configuration ────────────────────────────────────────────────────────────
SITE_ID = "e1ffb988-b764-44cf-a3ad-84086813ba4c"
PROJECT_ROOT = Path(__file__).resolve().parent

# Proxy URL from the Netlify MCP deploy-services-updater response.
# This carries the authenticated session token.
PROXY_URL = (
    "https://netlify-mcp.netlify.app/proxy/"
    "eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIn0.."
    "9YpCgdNIBzhiW9i7.7TZnxl5EKrcuYWjP8fdIOPb_TYf_bhxuMBKeZStsUnA8o22Q"
    "IcpIJk9MPHmj5T-ZcLapfk3KFu7BgpMAtFFAj_-Ez1Y-Wiupfjr0Jhj1kthSMEkMW"
    "_apvYEQlIkMqPpOMYtvRcDaQqscNytlbj2CX-k0tvskEahW60cu4IRvsQgrTaU1zjN"
    "LHxChZpfrarcIfOd0ajnL4Ahvf3IvIEKRkxez4vbO64oQXc6HO6km1CMayWgpOKBud"
    "qT9rIs2qOqq_SZ7GRcqvyK7Ye7J0j_5bdbX8OA10j5y3FvQ_p8mL09Mcy7Uk126O2"
    "ymXjtXmjXbOzXTrsEXJP0WIKnyRbz5P0-e4ypi7XHnzo1zP8qJZ_fqeRGM37ivM2lk"
    "qOoQ3rJTr57Os0zeTkx-2MBzCyZHUp7sC6Q.nqnDgIqBdqG0LWmSMMVhdA"
)

# Netlify API base URL
NETLIFY_API = "https://api.netlify.com/api/v1"

# ─── Paths to skip ───────────────────────────────────────────────────────────
SKIP_DIRS = {
    ".venv", "__pycache__", ".git", ".pytest_cache",
    ".mypy_cache", "node_modules", "instance", "uploads",
    "tests", ".system_generated",
}
SKIP_EXTENSIONS = {".pyc", ".pyo", ".db", ".sqlite", ".log", ".DS_Store"}
SKIP_FILES = {"deploy_to_netlify.py", "deploy_via_api.py"}


def should_skip(path: Path) -> bool:
    """Return True if the given path should be excluded from the ZIP."""
    for part in path.parts:
        if part in SKIP_DIRS:
            return True
    if path.suffix in SKIP_EXTENSIONS:
        return True
    if path.name in SKIP_FILES:
        return True
    return False


def build_zip() -> bytes:
    """Create an in-memory ZIP of the project."""
    buf = io.BytesIO()
    added = []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
        for abs_path in sorted(PROJECT_ROOT.rglob("*")):
            if abs_path.is_dir():
                continue
            rel = abs_path.relative_to(PROJECT_ROOT)
            if should_skip(rel):
                continue
            arc_name = rel.as_posix()
            zf.write(abs_path, arc_name)
            added.append(arc_name)
    buf.seek(0)
    data = buf.read()
    print(f"  ZIP contains {len(added)} files, size = {len(data):,} bytes")
    return data


def deploy_zip(zip_bytes: bytes, token: str) -> dict:
    """POST the ZIP to Netlify's deploys endpoint."""
    url = f"{NETLIFY_API}/sites/{SITE_ID}/deploys"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/zip",
    }
    print(f"  Posting to {url} ...")
    resp = requests.post(url, headers=headers, data=zip_bytes, timeout=300)
    print(f"  Response status: {resp.status_code}")
    if resp.status_code not in (200, 201):
        print("  Response body:", resp.text[:2000])
        resp.raise_for_status()
    return resp.json()


def get_token_via_proxy() -> str | None:
    """
    Try to retrieve a Netlify personal-access token via the MCP proxy.
    The proxy acts as an authenticated relay — if it exposes token info,
    we can extract it here. Otherwise, we fall back to env var.
    """
    token = os.environ.get("NETLIFY_AUTH_TOKEN") or os.environ.get("NETLIFY_TOKEN")
    if token:
        return token.strip()
    # Try the proxy endpoint for token exchange
    try:
        resp = requests.get(PROXY_URL + "/token", timeout=15)
        if resp.ok:
            data = resp.json()
            return data.get("access_token") or data.get("token")
    except Exception:
        pass
    return None


def wait_for_deploy(deploy_id: str, token: str) -> None:
    """Poll deploy status until ready or failed."""
    import time
    url = f"{NETLIFY_API}/deploys/{deploy_id}"
    headers = {"Authorization": f"Bearer {token}"}
    print(f"\n  Waiting for deploy {deploy_id} to complete...")
    for attempt in range(60):
        time.sleep(5)
        resp = requests.get(url, headers=headers, timeout=30)
        if not resp.ok:
            print(f"  Status check failed: {resp.status_code}")
            continue
        data = resp.json()
        state = data.get("state", "unknown")
        print(f"  [{attempt * 5}s] State: {state}")
        if state == "ready":
            print(f"\n  ✅ Deploy READY!")
            print(f"  🌐 URL: {data.get('deploy_ssl_url') or data.get('url')}")
            return
        if state in ("error", "failed"):
            print(f"\n  ❌ Deploy FAILED. Error ID: {data.get('error_message')}")
            print(json.dumps(data, indent=2)[:2000])
            sys.exit(1)
    print("  ⏰ Timed out waiting for deploy. Check Netlify dashboard.")


def main():
    print("=" * 60)
    print("Group No1 — Netlify ZIP Deploy")
    print("=" * 60)

    # Step 1: Get auth token
    print("\n[1/4] Resolving Netlify auth token...")
    token = get_token_via_proxy()
    if not token:
        print(
            "\n  ❌ No Netlify token found.\n"
            "  Set NETLIFY_AUTH_TOKEN env var:\n"
            "    $env:NETLIFY_AUTH_TOKEN='<your-token>'\n"
            "  Get one at: https://app.netlify.com/user/applications#personal-access-tokens"
        )
        sys.exit(1)
    masked = token[:6] + "..." + token[-4:] if len(token) > 12 else "***"
    print(f"  Token resolved: {masked}")

    # Step 2: Build ZIP
    print("\n[2/4] Building ZIP archive...")
    zip_bytes = build_zip()

    # Step 3: Deploy
    print("\n[3/4] Uploading to Netlify...")
    result = deploy_zip(zip_bytes, token)
    deploy_id = result.get("id")
    state = result.get("state", "unknown")
    print(f"  Deploy ID: {deploy_id}")
    print(f"  Initial state: {state}")

    # Step 4: Wait
    print("\n[4/4] Monitoring deploy...")
    if state == "ready":
        url = result.get("deploy_ssl_url") or result.get("url")
        print(f"  ✅ Already ready! URL: {url}")
    elif deploy_id:
        wait_for_deploy(deploy_id, token)
    else:
        print("  Deploy response:", json.dumps(result, indent=2)[:1000])

    print("\nDone.")


if __name__ == "__main__":
    main()
